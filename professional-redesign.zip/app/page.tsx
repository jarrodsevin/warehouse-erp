import Link from 'next/link'
import Sidebar from './components/Sidebar'

const modules = [
  {
    name: 'Products',
    description: 'Manage inventory and pricing',
    href: '/products',
    icon: '📦',
    stats: 'Inventory Management'
  },
  {
    name: 'Customers',
    description: 'Customer accounts and information',
    href: '/customers/options',
    icon: '👥',
    stats: 'CRM'
  },
  {
    name: 'Vendors',
    description: 'Vendor contacts and management',
    href: '/vendors',
    icon: '🏢',
    stats: 'Procurement'
  },
  {
    name: 'Purchase Orders',
    description: 'Create and track purchase orders',
    href: '/purchase-orders',
    icon: '🛒',
    stats: 'Supply Chain'
  },
  {
    name: 'Sales Orders',
    description: 'Manage customer sales orders',
    href: '/sales-orders',
    icon: '💰',
    stats: 'Sales Management'
  },
  {
    name: 'Sales Visits',
    description: 'Record and track customer visits',
    href: '/sales-visits',
    icon: '📍',
    stats: 'Field Operations'
  },
  {
    name: 'Reports',
    description: 'Analytics and profitability insights',
    href: '/reports',
    icon: '📈',
    stats: 'Business Intelligence'
  },
  {
    name: 'Admin',
    description: 'System settings and data management',
    href: '/admin',
    icon: '⚙️',
    stats: 'Configuration'
  },
]

export default function Dashboard() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 ml-64">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome to ApexFlow ERP System</p>
        </div>

        {/* Content */}
        <div className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {modules.map((module) => (
              <Link
                key={module.href}
                href={module.href}
                className="group bg-white rounded-lg border border-gray-200 p-6 hover:border-primary-600 hover:shadow-md transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center text-2xl group-hover:bg-primary-100 transition-colors">
                    {module.icon}
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-primary-800">
                  {module.name}
                </h3>
                <p className="text-sm text-gray-600 mb-3">
                  {module.description}
                </p>
                <div className="flex items-center text-xs text-gray-500">
                  <span className="px-2 py-1 bg-gray-50 rounded">{module.stats}</span>
                </div>
              </Link>
            ))}
          </div>

          {/* Quick Stats Section */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Products</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">-</p>
                </div>
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">📦</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Orders</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">-</p>
                </div>
                <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">📋</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Revenue (MTD)</p>
                  <p className="text-2xl font-semibold text-gray-900 mt-1">-</p>
                </div>
                <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">💰</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}