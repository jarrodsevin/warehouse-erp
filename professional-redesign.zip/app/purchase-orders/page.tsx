import Link from 'next/link'
import PageLayout from '../components/PageLayout'

const actions = [
  {
    title: 'Create Purchase Order',
    description: 'Place a new order with vendors',
    href: '/purchase-orders/create',
    icon: '➕',
  },
  {
    title: 'Receive Inventory',
    description: 'Record incoming shipments',
    href: '/purchase-orders/receive',
    icon: '📦',
  },
  {
    title: 'Update Order',
    description: 'Modify existing purchase orders',
    href: '/purchase-orders/update',
    icon: '✏️',
  },
  {
    title: 'View Orders',
    description: 'Browse purchase order history',
    href: '/purchase-orders/view',
    icon: '👁️',
  },
]

export default function PurchaseOrdersMenu() {
  return (
    <PageLayout 
      title="Purchase Orders" 
      subtitle="Manage procurement and incoming inventory"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl">
        {actions.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="bg-white rounded-lg border border-gray-200 p-8 hover:border-primary-600 hover:shadow-md transition-all group"
          >
            <div className="w-14 h-14 bg-primary-50 rounded-lg flex items-center justify-center text-3xl mb-4 group-hover:bg-primary-100 transition-colors">
              {action.icon}
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-primary-800">
              {action.title}
            </h2>
            <p className="text-gray-600">
              {action.description}
            </p>
          </Link>
        ))}
      </div>
    </PageLayout>
  )
}
