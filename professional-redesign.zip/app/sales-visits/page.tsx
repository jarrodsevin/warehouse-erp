import Link from 'next/link'
import PageLayout from '../components/PageLayout'

const actions = [
  {
    title: 'View Sales Visits',
    description: 'Browse customer visit history',
    href: '/sales-visits/view',
    icon: '📋',
  },
]

export default function SalesVisitsMenu() {
  return (
    <PageLayout 
      title="Sales Visits" 
      subtitle="Track field operations and customer interactions"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
        {actions.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="bg-white rounded-lg border border-gray-200 p-8 hover:border-primary-600 hover:shadow-md transition-all group"
          >
            <div className="w-14 h-14 bg-primary-50 rounded-lg flex items-center justify-center text-3xl mb-4 group-hover:bg-primary-100 transition-colors">
              {action.icon}
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-primary-800">
              {action.title}
            </h2>
            <p className="text-gray-600">
              {action.description}
            </p>
          </Link>
        ))}
      </div>
    </PageLayout>
  )
}
