import Sidebar from './Sidebar'

interface PageLayoutProps {
  children: React.ReactNode
  title?: string
  subtitle?: string
}

export default function PageLayout({ children, title, subtitle }: PageLayoutProps) {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 ml-64">
        {/* Header */}
        {(title || subtitle) && (
          <div className="bg-white border-b border-gray-200 px-8 py-6">
            {title && <h1 className="text-2xl font-semibold text-gray-900">{title}</h1>}
            {subtitle && <p className="text-gray-600 mt-1">{subtitle}</p>}
          </div>
        )}
        
        {/* Content */}
        <div className="p-8">
          {children}
        </div>
      </main>
    </div>
  )
}
