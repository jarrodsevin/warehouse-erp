import Link from 'next/link'
import PageLayout from '../components/PageLayout'

const adminSections = [
  {
    title: 'Categories',
    description: 'Manage product categories',
    href: '/admin/categories',
    icon: '📁',
  },
  {
    title: 'Subcategories',
    description: 'Manage product subcategories',
    href: '/admin/subcategories',
    icon: '🏷️',
  },
  {
    title: 'Brands',
    description: 'Manage product brands',
    href: '/admin/brands',
    icon: '🏢',
  },
]

export default function AdminMenu() {
  return (
    <PageLayout 
      title="Administration" 
      subtitle="System configuration and data management"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl">
        {adminSections.map((section) => (
          <Link
            key={section.href}
            href={section.href}
            className="bg-white rounded-lg border border-gray-200 p-8 hover:border-primary-600 hover:shadow-md transition-all group"
          >
            <div className="w-14 h-14 bg-primary-50 rounded-lg flex items-center justify-center text-3xl mb-4 group-hover:bg-primary-100 transition-colors">
              {section.icon}
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-primary-800">
              {section.title}
            </h2>
            <p className="text-gray-600">
              {section.description}
            </p>
          </Link>
        ))}
      </div>
    </PageLayout>
  )
}
