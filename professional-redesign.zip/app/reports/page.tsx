import Link from 'next/link'
import PageLayout from '../components/PageLayout'

const reports = [
  {
    title: 'Product Profitability',
    description: 'Compare individual products by profitability with multi-dimensional filtering',
    href: '/reports/product-profitability',
    icon: '📊',
  },
  {
    title: 'Category Analysis',
    description: 'Analyze profitability by product categories with subcategory and brand breakdowns',
    href: '/reports/category-analysis',
    icon: '📁',
  },
  {
    title: 'Subcategory Analysis',
    description: 'Deep dive into subcategory performance across categories and brands',
    href: '/reports/subcategory-analysis',
    icon: '🏷️',
  },
  {
    title: 'Brand Analysis',
    description: 'Compare brand performance across categories and subcategories',
    href: '/reports/brand-analysis',
    icon: '🏢',
  },
  {
    title: 'Customer Sales Performance',
    description: 'Analyze customer profitability and sales performance with time-based filtering',
    href: '/reports/customer-sales',
    icon: '👥',
  },
  {
    title: 'Discount & Pricing Analysis',
    description: 'Compare potential profit at retail vs actual profit with discounts applied',
    href: '/reports/discount-analysis',
    icon: '💰',
  },
  {
    title: 'Inventory Value',
    description: 'View current inventory value and stock levels',
    href: '/reports/inventory-value',
    icon: '📦',
  },
]

export default function ReportsMenu() {
  return (
    <PageLayout 
      title="Reports & Analytics" 
      subtitle="Business intelligence and performance insights"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report) => (
          <Link
            key={report.href}
            href={report.href}
            className="bg-white rounded-lg border border-gray-200 p-6 hover:border-primary-600 hover:shadow-md transition-all group"
          >
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center text-2xl flex-shrink-0 group-hover:bg-primary-100 transition-colors">
                {report.icon}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-lg font-semibold text-gray-900 mb-2 group-hover:text-primary-800">
                  {report.title}
                </h2>
                <p className="text-sm text-gray-600">
                  {report.description}
                </p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </PageLayout>
  )
}
