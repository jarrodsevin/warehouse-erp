import Link from 'next/link'
import PageLayout from '../components/PageLayout'

const actions = [
  {
    title: 'Create New Product',
    description: 'Add a new product to your catalog',
    href: '/products/create',
    icon: '➕',
    color: 'green'
  },
  {
    title: 'Update Product',
    description: 'Edit existing product information',
    href: '/products/update',
    icon: '✏️',
    color: 'blue'
  },
  {
    title: 'View Products',
    description: 'Browse and search product database',
    href: '/products/view',
    icon: '👁️',
    color: 'purple'
  },
]

export default function ProductsMenu() {
  return (
    <PageLayout 
      title="Products" 
      subtitle="Manage your product catalog and inventory"
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl">
        {actions.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="bg-white rounded-lg border border-gray-200 p-8 hover:border-primary-600 hover:shadow-md transition-all group"
          >
            <div className="w-14 h-14 bg-primary-50 rounded-lg flex items-center justify-center text-3xl mb-4 group-hover:bg-primary-100 transition-colors">
              {action.icon}
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2 group-hover:text-primary-800">
              {action.title}
            </h2>
            <p className="text-gray-600">
              {action.description}
            </p>
          </Link>
        ))}
      </div>
    </PageLayout>
  )
}
