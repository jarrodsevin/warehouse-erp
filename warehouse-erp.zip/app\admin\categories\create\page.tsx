import CategoryForm from '@/app/components/CategoryForm'
import Link from 'next/link'

export default function CreateCategoryPage() {
  return (
    <div className="min-h-screen p-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-8">
          <Link href="/admin/categories" className="text-primary-600 hover:text-primary-700">
            ← Back to Categories Menu
          </Link>
        </div>
        
        <h1 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
          Create New Category
        </h1>

        <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm">
          <CategoryForm />
        </div>
      </div>
    </div>
  )
}