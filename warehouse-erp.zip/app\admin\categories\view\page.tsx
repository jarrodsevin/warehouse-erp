import Link from 'next/link'
import { prisma } from '@/prisma/prisma.config'

export default async function ViewCategoriesPage() {
  const categories = await prisma.category.findMany({
    include: {
      _count: {
        select: { products: true }
      }
    },
    orderBy: { name: 'asc' }
  })

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link href="/admin/categories" className="text-primary-600 hover:text-primary-700">
            ← Back to Categories Menu
          </Link>
        </div>

        <h1 className="text-3xl font-bold mb-4 text-center bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
          View Categories
        </h1>

        <p className="text-center text-gray-600 mb-12">All product categories</p>

        <div className="space-y-4">
          {categories.map((category) => (
            <div key={category.id} className="bg-white border border-gray-200 rounded-lg p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-2xl font-semibold text-warning-dark">{category.name}</h3>
                  <p className="text-gray-600 text-sm mt-2">
                    {category._count.products} product{category._count.products !== 1 ? 's' : ''} in this category
                  </p>
                </div>
                <div className="text-gray-600 text-sm">
                  Created: {new Date(category.createdAt).toLocaleDateString()}
                </div>
              </div>
            </div>
          ))}
        </div>

        {categories.length === 0 && (
          <p className="text-center text-gray-600 mt-8">No categories found.</p>
        )}
      </div>
    </div>
  )
}