"use client";

/**
 * Customers route final-order CSS overrides
 * Applies the unified light theme and readable typography to:
 *   /customers, /customers/options, /customers/add
 */
export default function RouteOverrides() {
  return (
    <style jsx global>{`
      /* Light panels instead of legacy dark backgrounds (incl. opacity/arbitrary) */
      .unify-theme [class*="bg-gray-900"],
      .unify-theme [class*="bg-gray-900/"],
      .unify-theme [class*="bg-slate-900"],
      .unify-theme [class*="bg-slate-900/"],
      .unify-theme [class*="bg-neutral-900"],
      .unify-theme [class*="bg-neutral-900/"],
      .unify-theme [class*="bg-[#"],
      .unify-theme [class*="bg-[rgb"],
      .unify-theme [class*="bg-[rgba"] {
        background-color: #ffffff !important;
        color: #0f172a !important;
        border-color: #e5e7eb !important;
      }

      /* Card-level darks → light cards */
      .unify-theme [class*="bg-gray-800"],
      .unify-theme [class*="bg-gray-800/"],
      .unify-theme [class*="bg-slate-800"],
      .unify-theme [class*="bg-slate-800/"],
      .unify-theme [class*="bg-neutral-800"],
      .unify-theme [class*="bg-neutral-800/"] {
        background-color: #f9fafb !important;
        color: #0f172a !important;
        border-color: #e5e7eb !important;
      }

      /* Base text contrast */
      .unify-theme,
      .unify-theme p,
      .unify-theme span,
      .unify-theme li,
      .unify-theme small,
      .unify-theme label {
        color: #1f2937 !important; /* gray-800 */
      }
      .unify-theme .text-gray-300,
      .unify-theme .text-slate-300,
      .unify-theme .text-gray-400,
      .unify-theme .text-slate-400,
      .unify-theme .text-gray-500,
      .unify-theme .text-slate-500 {
        color: #374151 !important; /* gray-700 */
      }
      .unify-theme .text-white {
        color: #0f172a !important; /* prevent invisible text on light bg */
      }

      /* Normalize oversized centered "hero" headings some customer pages render */
      .unify-theme h1 {
        color: #111827 !important;          /* gray-900 */
        font-weight: 700 !important;         /* bold like Products title */
        text-align: left !important;         /* match Products header alignment */
        font-size: 1.875rem !important;      /* text-3xl */
        line-height: 2.25rem !important;
        margin: 0 0 0.5rem 0 !important;     /* tighten spacing like Products */
      }
      .unify-theme h2,
      .unify-theme h3,
      .unify-theme h4 {
        color: #111827 !important;
        font-weight: 600 !important;
        text-align: left !important;
      }

      /* Inputs: ensure light fields */
      .unify-theme input,
      .unify-theme textarea,
      .unify-theme select {
        background-color: #ffffff !important;
        color: #0f172a !important;
        border-color: #e5e7eb !important;
        box-shadow: none !important;
      }
      .unify-theme input::placeholder {
        color: #6b7280 !important; /* gray-500/600 */
      }

      /* Tables on /customers pages (found bg-gray-900 thead and gray-800 containers) */
      .unify-theme table thead,
      .unify-theme thead[class*="bg-gray-900"],
      .unify-theme thead[class*="bg-slate-900"] {
        background-color: #f9fafb !important; /* light header */
      }
      .unify-theme thead th,
      .unify-theme thead td {
        color: #374151 !important;  /* gray-700 */
        border-color: #e5e7eb !important;
        font-weight: 600 !important;
      }
      .unify-theme tbody td,
      .unify-theme tbody th {
        border-color: #e5e7eb !important;
      }
      .unify-theme tr[class*="bg-gray-800"],
      .unify-theme tr[class*="bg-slate-800"] {
        background-color: #ffffff !important;
      }

      /* Action chips/buttons that used dark backgrounds (e.g., bg-gray-800 text-white) */
      .unify-theme .bg-gray-800.text-white,
      .unify-theme .bg-slate-800.text-white,
      .unify-theme button[class*="rounded"][class*="bg-gray-800"],
      .unify-theme a[class*="rounded"][class*="bg-gray-800"] {
        background-color: #111827 !important;  /* gray-900 */
        color: #ffffff !important;
        border: 0 !important;
      }
      .unify-theme .hover\\:bg-gray-700:hover,
      .unify-theme .hover\\:bg-slate-700:hover {
        background-color: #0f172a !important; /* darker hover */
      }
      .unify-theme button[class*="rounded"][class*="bg-gray-800"] svg,
      .unify-theme a[class*="rounded"][class*="bg-gray-800"] svg {
        color: #ffffff !important;
        fill: currentColor !important;
      }

      /* Muted, readable badges (if any) */
      .unify-theme [class*="rounded-full"][class*="bg-blue"],
      .unify-theme [class*="rounded-full"][class*="bg-indigo"] {
        background-color: #eef2ff !important; /* indigo-50 */
        color: #3730a3 !important;           /* indigo-700 */
        border: 1px solid #e0e7ff !important;
      }
      .unify-theme [class*="rounded-full"][class*="bg-amber"],
      .unify-theme [class*="rounded-full"][class*="bg-orange"] {
        background-color: #fff7ed !important; /* orange-50 */
        color: #9a3412 !important;            /* orange-800 */
        border: 1px solid #ffedd5 !important;
      }

      /* Soften generic borders/dividers */
      .unify-theme .border,
      .unify-theme [class*="border-"] {
        border-color: #e5e7eb !important; /* gray-200 */
      }
    `}</style>
  );
}
