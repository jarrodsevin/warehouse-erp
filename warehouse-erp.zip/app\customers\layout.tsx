// app/customers/layout.tsx
import React from "react";
import PageLayout from "../components/PageLayout";
import RouteOverrides from "./RouteOverrides"; // client-side CSS injector

export default function CustomersLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <PageLayout
      title="Customers"
      subtitle="Manage customers, pricing, and options"
      breadcrumbs={[
        { label: "Dashboard", href: "/" },
        { label: "Customers", href: "/customers" },
      ]}
    >
      {/* Keep all /customers pages inside the same theme wrapper */}
      <div className="unify-theme">
        {children}
        <RouteOverrides />
      </div>
    </PageLayout>
  );
}
