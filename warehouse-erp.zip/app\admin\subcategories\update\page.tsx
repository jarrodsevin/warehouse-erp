import { prisma } from '@/prisma/prisma.config'
import Link from 'next/link'

export default async function UpdateSubcategories() {
  const subcategories = await prisma.subcategory.findMany({
    orderBy: {
      name: 'asc',
    },
  })

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/admin/subcategories" className="text-primary-600 hover:text-primary-700">
            ← Back to Subcategories
          </Link>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
            Update Subcategories
          </h1>
          <p className="text-gray-600">Click on a subcategory to edit it</p>
        </div>

        {subcategories.length === 0 ? (
          <div className="bg-white border border-gray-200 rounded-lg p-8 text-center">
            <p className="text-gray-600">No subcategories found. Create one to get started!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subcategories.map((subcategory) => (
              <Link
                key={subcategory.id}
                href={`/admin/subcategories/${subcategory.id}`}
                className="bg-white border border-gray-200 rounded-lg p-6  hover:shadow-lg transition-all cursor-pointer"
              >
                <h3 className="text-xl font-semibold text-warning-dark">{subcategory.name}</h3>
                <p className="text-sm text-gray-600 mt-2">Click to edit</p>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}