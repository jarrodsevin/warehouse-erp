"use client";

/**
 * RouteOverrides
 * Injects final order CSS overrides for /products/view
 * Keeps Server Components untouched and avoids styled-jsx errors
 */
export default function RouteOverrides() {
  return (
    <style jsx global>{`
      /* Light surfaces for any dark panel utilities */
      .unify-theme [class*="bg-gray-900"],
      .unify-theme [class*="bg-gray-900/"],
      .unify-theme [class*="bg-slate-900"],
      .unify-theme [class*="bg-slate-900/"],
      .unify-theme [class*="bg-neutral-900"],
      .unify-theme [class*="bg-neutral-900/"],
      .unify-theme [class*="bg-[#"],
      .unify-theme [class*="bg-[rgb"],
      .unify-theme [class*="bg-[rgba"] {
        background-color: #ffffff !important;
        color: #0f172a !important;
        border-color: #e5e7eb !important;
      }

      /* 800 tier to light card */
      .unify-theme [class*="bg-gray-800"],
      .unify-theme [class*="bg-gray-800/"],
      .unify-theme [class*="bg-slate-800"],
      .unify-theme [class*="bg-slate-800/"],
      .unify-theme [class*="bg-neutral-800"],
      .unify-theme [class*="bg-neutral-800/"] {
        background-color: #f9fafb !important;
        color: #0f172a !important;
        border-color: #e5e7eb !important;
      }

      /* Inputs inside those panels */
      .unify-theme input,
      .unify-theme textarea,
      .unify-theme select {
        background-color: #ffffff !important;
        color: #0f172a !important;
        border-color: #e5e7eb !important;
      }

      /* Heading and body contrast */
      .unify-theme h1,
      .unify-theme h2,
      .unify-theme h3,
      .unify-theme h4 {
        color: #111827 !important;
        font-weight: 600 !important;
      }

      .unify-theme,
      .unify-theme p,
      .unify-theme span,
      .unify-theme li,
      .unify-theme small,
      .unify-theme label {
        color: #1f2937 !important; /* gray-800 */
      }

      .unify-theme .text-gray-300,
      .unify-theme .text-slate-300,
      .unify-theme .text-gray-400,
      .unify-theme .text-slate-400,
      .unify-theme .text-gray-500,
      .unify-theme .text-slate-500 {
        color: #374151 !important; /* gray-700 */
      }

      /* Calm hyper saturated metric accents */
      .unify-theme .text-purple-400,
      .unify-theme .text-purple-500,
      .unify-theme .text-fuchsia-400,
      .unify-theme .text-pink-400 {
        color: #4f46e5 !important; /* indigo-600 */
      }

      .unify-theme .text-yellow-400,
      .unify-theme .text-amber-400,
      .unify-theme .text-orange-400 {
        color: #374151 !important; /* gray-700 */
      }

      .unify-theme .text-cyan-400,
      .unify-theme .text-teal-400,
      .unify-theme .text-blue-400 {
        color: #0369a1 !important; /* cyan-700 */
      }

      /* Pills and badges */
      .unify-theme [class*="rounded-full"][class*="bg-"] {
        border: 1px solid #e5e7eb !important;
      }

      .unify-theme [class*="rounded-full"][class*="bg-blue"],
      .unify-theme [class*="rounded-full"][class*="bg-indigo"] {
        background-color: #eef2ff !important;
        color: #3730a3 !important;
        border-color: #e0e7ff !important;
      }

      .unify-theme [class*="rounded-full"][class*="bg-amber"],
      .unify-theme [class*="rounded-full"][class*="bg-orange"] {
        background-color: #fff7ed !important;
        color: #9a3412 !important;
        border-color: #ffedd5 !important;
      }

      .unify-theme [class*="rounded-full"][class*="bg-cyan"],
      .unify-theme [class*="rounded-full"][class*="bg-teal"],
      .unify-theme [class*="rounded-full"][class*="bg-sky"] {
        background-color: #e0f2fe !important;
        color: #075985 !important;
        border-color: #bae6fd !important;
      }

      /* Show or Hide chip base style */
      .unify-theme [class*="rounded-full"][class*="Show"],
      .unify-theme [class*="rounded-full"][class*="Hide"],
      .unify-theme button[class*="rounded-full"],
      .unify-theme a[class*="rounded-full"] {
        background-color: #111827 !important; /* gray-900 */
        color: #ffffff !important;
        border: 0 !important;
        padding: 0.375rem 0.75rem !important;
        font-weight: 600 !important;
        line-height: 1.25rem !important;
      }

      .unify-theme button[class*="rounded-full"] svg,
      .unify-theme a[class*="rounded-full"] svg {
        color: #ffffff !important;
        fill: currentColor !important;
      }

      /* Calm product title color and general link blues */
      .unify-theme .text-blue-600,
      .unify-theme .text-blue-500,
      .unify-theme a.text-blue-600,
      .unify-theme a.text-blue-500 {
        color: #1f2937 !important; /* gray-800 */
      }

      /* If product name is an h2/h3, ensure strong readable tone */
      .unify-theme h2,
      .unify-theme h3 {
        color: #1f2937 !important; /* gray-800 */
        font-weight: 700 !important;
      }

      /* Soften card borders and dividers */
      .unify-theme .border,
      .unify-theme [class*="border-"] {
        border-color: #e5e7eb !important; /* gray-200 */
      }

      /* Ensure white filter input with readable placeholder */
      .unify-theme input::placeholder {
        color: #374151 !important; /* gray-700 placeholder */
      }

      .unify-theme input {
        background-color: #ffffff !important;
        border-color: #e5e7eb !important;
        box-shadow: none !important;
      }

      /* === LIVE DOM PRECISE FIXES === */

      /* 1) Product title with .text-blue-400 */
      .unify-theme h2.text-blue-400,
      .unify-theme .text-blue-400 {
        color: #1f2937 !important;
      }

      /* 2) “Show (n)” pill uses bg-gray-700 + rounded-lg */
      .unify-theme button.rounded-lg.bg-gray-700,
      .unify-theme a.rounded-lg.bg-gray-700,
      .unify-theme span.rounded-lg.bg-gray-700 {
        background-color: #111827 !important;
        color: #ffffff !important;
        border: 0 !important;
      }

      /* 3) Hover override for Tailwind .hover:bg-gray-600 */
      .unify-theme .hover\\:bg-gray-600:hover {
        background-color: #0f172a !important;
      }

      /* 4) Make icons inside pills visible */
      .unify-theme button.rounded-lg.bg-gray-700 svg,
      .unify-theme a.rounded-lg.bg-gray-700 svg,
      .unify-theme span.rounded-lg.bg-gray-700 svg {
        color: #ffffff !important;
        fill: currentColor !important;
      }
    `}</style>
  );
}
